

protocol APIDataManagerInputProtocol: class
{
    func fetchCurrencyFromServerWithData(_ baseCurrencyCode: String, completion: (([Currency]) -> Void)!, failed:((AnyObject) -> Void)!)
}
