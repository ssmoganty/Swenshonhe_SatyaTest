//
//  Task3ViewController.swift
//  satya_test
//
//  Created by Satya on 05/01/2021.
//

import Foundation
import UIKit

class Task3ViewController: UIViewController {
    
    @IBOutlet weak var string1TF:UITextField!
    @IBOutlet weak var string2TF:UITextField!
    @IBOutlet weak var resultlbl:UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
        resultlbl.text = "";
    }
    
    @IBAction func textChanged(){
        if(string1TF.text != nil || string2TF.text != nil){
            if(string1TF.text!.isAnagramWith(secondString: string2TF.text!)){
                resultlbl.text = "True"
            }
            else{
                resultlbl.text = "False"
            }
        }
    }
    
    @IBAction func goBack(sender:UIButton){
        self.dismiss(animated: true, completion: nil)
    }
    
}
