//
//  ViewController.swift
//  satya_test
//
//  Created by Satya on 04/01/2021.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
      
    }

    @IBAction func clickonTasks(sender:UIButton){
        switch sender.tag {
        case 1:
            let next = self.storyboard?.instantiateViewController(withIdentifier: "Task2View") as! Task2ViewController
                   next.modalPresentationStyle = .fullScreen
                   self.present(next, animated: false, completion: nil)
            break
        case 2:
            let next = self.storyboard?.instantiateViewController(withIdentifier: "Task3View") as! Task3ViewController
                   next.modalPresentationStyle = .fullScreen
                   self.present(next, animated: false, completion: nil)
            break
        case 3:
            let next = self.storyboard?.instantiateViewController(withIdentifier: "Task4View") as! Task4ViewController
                   next.modalPresentationStyle = .fullScreen
                   self.present(next, animated: false, completion: nil)
            break
        case 4:
            let next = self.storyboard?.instantiateViewController(withIdentifier: "Task1Forex") as! Task1ViewController
                   next.modalPresentationStyle = .fullScreen
                   self.present(next, animated: false, completion: nil)
            break
        default:
            break
        }
    }

}

