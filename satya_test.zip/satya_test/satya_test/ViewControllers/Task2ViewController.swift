//
//  Task2ViewController.swift
//  satya_test
//
//  Created by Satya on 05/01/2021.
//

import Foundation
import UIKit

class Task2ViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func goBack(sender:UIButton){
        self.dismiss(animated: true, completion: nil)
    }
    
}
