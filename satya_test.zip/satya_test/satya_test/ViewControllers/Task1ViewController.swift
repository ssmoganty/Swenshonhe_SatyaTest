//
//  Task1ViewController.swift
//  satya_test
//
//  Created by Satya on 05/01/2021.
//

import Foundation
import UIKit

protocol SelectMainCurrencyVCProtocol: class{
    func selectMainCurrency(currency: Currency)
}

class Task1ViewController: UIViewController {
    
    var delegate:SelectMainCurrencyVCProtocol?
    var APIDataManager: APIDataManagerInputProtocol?
    @IBOutlet weak var currenciesTableView:UITableView!
    private let reuseId = "MoneyViewCell"
    var currencies:[Currency] = []

    var vm: ForexProtocolClass?{
        didSet {
            vm?.delegate = self
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        vm = ForexClassModel()
        vm?.loadCurrencies()
    
        currenciesTableView.dataSource = self
        currenciesTableView.delegate = self
        currenciesTableView.register(UINib(nibName: "MoneyViewCell", bundle: nil), forCellReuseIdentifier: "MoneyViewCell")
        currenciesTableView.rowHeight = UITableView.automaticDimension
        
     
    }
    func showConverterView(currency: Currency){
        if let vc = storyboard?.instantiateViewController(identifier: "Task1ForexDetail") as? Task1ForexDetailViewController{
            vc.currency = currency
            vc.vm = self.vm
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: false, completion: nil)

           // navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    @IBAction func goBack(sender:UIButton){
        self.dismiss(animated: true, completion: nil)

    }
}
extension Task1ViewController: UITableViewDelegate{
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if let currency = vm?.currencies[indexPath.row]{
            showConverterView(currency: currency)
        }
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
}

extension Task1ViewController: UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return vm?.currencies.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: reuseId, for: indexPath) as! MoneyViewCell
        if let currency = vm?.currencies[indexPath.row]{
            cell.forex_rate_lbl.text = vm?.formattedNameWithFlag(currency: currency)
            cell.forex_name_lbl.text = vm?.formattedNumber(currency: currency)
        }
        return cell
    }
    
}

extension Task1ViewController: CurrenciesListVCOutputProtocol{
    func finishLoadingCurrencies(success: Bool) {
        if success{
            currenciesTableView.reloadData()
        }else{
        }
    }
}

extension Task1ViewController: SelectMainCurrencyVCProtocol{
    func selectMainCurrency(currency: Currency) {
        vm?.selectedCurrency = currency
        var ccode = currency.name
        ccode.removeLast()
    }
}

