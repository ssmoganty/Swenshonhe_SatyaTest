//
//  Task4ViewController.swift
//  satya_test
//
//  Created by Satya on 05/01/2021.
//

import Foundation
import UIKit

class Task4ViewController: UIViewController {
    
    @IBOutlet weak var string1TF:UITextField!
    @IBOutlet weak var resultlbl1:UITextView!
    @IBOutlet weak var resultlbl2:UITextView!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        for s in sequenceByRecursion(state_first: (0, 1), while: { $1 <= 40 }, state_next: { ($1, $0 + $1)}) {
            print(s.1)
          //  resultlbl1.text = String(s.1)
        }
        print(fibGeneratorByItterations(8))
        
        let iterateString = fibGeneratorByItterations(8).map { String($0) }
            .joined(separator: ", ")
        
        resultlbl1.text = iterateString
    }
    
    
    @IBAction func goBack(sender:UIButton){
        self.dismiss(animated: true, completion: nil)
    }
    
    public func sequenceByRecursion<T>(state_first: T, while condition: @escaping (T)-> Bool, state_next: @escaping (T) -> T) -> UnfoldSequence<T, T> {
        let state_next = { (stateToCheck: inout T) -> T? in
            guard condition(stateToCheck) else { return nil }
            defer { stateToCheck = state_next(stateToCheck) }
            return stateToCheck
        }
        return Swift.sequence(state: state_first, next: state_next)
    }
    func fibGeneratorByItterations(_ n: Int) -> [Int] {
        var fibArray: [Int] = [1, 1]
        (2...n).forEach { i in
            fibArray.append(fibArray[i - 1] + fibArray[i - 2])
        }
        return fibArray
    }
}
