//
//  Currency.swift
//  satya_test
//
//  Created by Satya on 05/01/2021.
//


struct Currency{
    let name:String
    let ratio:Double
}
