//
//  MoneyViewCell.swift
//  satya_test
//
//  Created by Satya on 05/01/2021.
//

import Foundation
import UIKit

class MoneyViewCell: UITableViewCell {
    @IBOutlet weak var forex_name_lbl:UILabel!
    @IBOutlet weak var forex_rate_lbl:UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
